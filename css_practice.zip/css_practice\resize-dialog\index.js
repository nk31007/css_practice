document.addEventListener('DOMContentLoaded', () => {
    const openDialogBtn = document.getElementById('openDialogBtn');
    const responsiveDialog = document.getElementById('responsiveDialog');
    const dialogContent = responsiveDialog.querySelector('.dialog-content');
    const dialogHeader = responsiveDialog.querySelector('.dialog-header');
    const closeButtons = responsiveDialog.querySelectorAll('.close-btn, .cancel-btn');

    // Make Dialog Draggable
    let isDragging = false;
    let initialX, initialY;
    let offsetX, offsetY;

    dialogHeader.addEventListener('mousedown', (e) => {
        if (!e.target.closest('.close-btn')) { // Don't drag if clicking the close button
            isDragging = true;
            dialogHeader.style.cursor = 'grabbing';
            // Get initial mouse position
            initialX = e.clientX;
            initialY = e.clientY;

            // Get current dialog position (relative to viewport)
            const dialogRect = dialogContent.getBoundingClientRect();
            offsetX = e.clientX - dialogRect.left;
            offsetY = e.clientY - dialogRect.top;

            // Prevent default drag behavior (e.g., text selection)
            e.preventDefault();
        }
    });

    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;

        // Calculate new position
        let newX = e.clientX - offsetX;
        let newY = e.clientY - offsetY;

        // Ensure dialog stays within viewport boundaries
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const dialogWidth = dialogContent.offsetWidth;
        const dialogHeight = dialogContent.offsetHeight;

        // Clamp X position
        newX = Math.max(0, newX);
        newX = Math.min(newX, viewportWidth - dialogWidth);

        // Clamp Y position
        newY = Math.max(0, newY);
        newY = Math.min(newY, viewportHeight - dialogHeight);

        dialogContent.style.left = `${newX}px`;
        dialogContent.style.top = `${newY}px`;
    });

    document.addEventListener('mouseup', () => {
        if (isDragging) {
            isDragging = false;
            dialogHeader.style.cursor = 'grab';
        }
    });


    // Make Dialog Resizable
    let isResizing = false;
    let currentResizer;
    let startX, startY;
    let startWidth, startHeight;
    let startLeft, startTop;

    const resizers = responsiveDialog.querySelectorAll('.resizer');

    resizers.forEach(resizer => {
        resizer.addEventListener('mousedown', (e) => {
            isResizing = true;
            currentResizer = resizer;
            startX = e.clientX;
            startY = e.clientY;

            const dialogRect = dialogContent.getBoundingClientRect();
            startWidth = dialogRect.width;
            startHeight = dialogRect.height;
            startLeft = dialogRect.left;
            startTop = dialogRect.top;

            e.preventDefault(); // Prevent default drag behavior
        });
    });

    document.addEventListener('mousemove', (e) => {
        if (!isResizing) return;

        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        let newWidth = startWidth;
        let newHeight = startHeight;
        let newLeft = startLeft;
        let newTop = startTop;

        const minWidth = parseInt(getComputedStyle(dialogContent).minWidth);
        const minHeight = parseInt(getComputedStyle(dialogContent).minHeight);

        switch (currentResizer.classList[1]) {
            case 'top-left':
                newWidth = startWidth - dx;
                newHeight = startHeight - dy;
                newLeft = startLeft + dx;
                newTop = startTop + dy;
                break;
            case 'top-right':
                newWidth = startWidth + dx;
                newHeight = startHeight - dy;
                newTop = startTop + dy;
                break;
            case 'bottom-left':
                newWidth = startWidth - dx;
                newHeight = startHeight + dy;
                newLeft = startLeft + dx;
                break;
            case 'bottom-right':
                newWidth = startWidth + dx;
                newHeight = startHeight + dy;
                break;
            case 'top':
                newHeight = startHeight - dy;
                newTop = startTop + dy;
                break;
            case 'bottom':
                newHeight = startHeight + dy;
                break;
            case 'left':
                newWidth = startWidth - dx;
                newLeft = startLeft + dx;
                break;
            case 'right':
                newWidth = startWidth + dx;
                break;
        }

        // Apply minimum size constraints
        if (newWidth >= minWidth) {
            dialogContent.style.width = `${newWidth}px`;
            if (currentResizer.classList.contains('left') || currentResizer.classList.contains('top-left') || currentResizer.classList.contains('bottom-left')) {
                dialogContent.style.left = `${newLeft}px`;
            }
        }
        if (newHeight >= minHeight) {
            dialogContent.style.height = `${newHeight}px`;
            if (currentResizer.classList.contains('top') || currentResizer.classList.contains('top-left') || currentResizer.classList.contains('top-right')) {
                dialogContent.style.top = `${newTop}px`;
            }
        }
    });

    document.addEventListener('mouseup', () => {
        isResizing = false;
        currentResizer = null;
    });

    // Dialog open/close functionality (from previous example, updated)
    openDialogBtn.addEventListener('click', () => {
        responsiveDialog.classList.add('show');
        // Reset dialog position to center when opened
        dialogContent.style.top = '50%';
        dialogContent.style.left = '50%';
        dialogContent.style.transform = 'translate(-50%, -50%)'; // Ensure it's centered
    });

    const closeDialog = () => {
        responsiveDialog.classList.remove('show');
    };

    closeButtons.forEach(button => {
        button.addEventListener('click', closeDialog);
    });

    responsiveDialog.addEventListener('click', (event) => {
        if (event.target === responsiveDialog) {
            closeDialog();
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && responsiveDialog.classList.contains('show')) {
            closeDialog();
        }
    });
});