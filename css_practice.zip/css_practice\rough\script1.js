// Get a reference to the close button
const closeButton = document.getElementById('closeButton');

// Get a reference to the nag div
const nagDiv = document.getElementById('first');

// Get a reference to the new 'Close' button at the bottom
const bottomCloseButton = document.getElementById('bottomCloseButton');

// Define the function to close the div
function closeNagMessage() {
    if (nagDiv) { // Check if the element exists before trying to hide it
        nagDiv.style.display = 'none'; // Or you could use nagDiv.remove() to remove it completely
    }
}

// Add an event listener to the button
closeButton.addEventListener('click', closeNagMessage);
bottomCloseButton.addEventListener('click', closeNagMessage);