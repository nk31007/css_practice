const closefunc = () => {
    const mye = document.getElementById("first")
    mye.style.display = 'none';
    }
const openfunc = () => {
    const mye = document.getElementById("first")
    mye.style.display = 'flex';
    }
