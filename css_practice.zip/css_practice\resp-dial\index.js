document.addEventListener('DOMContentLoaded', () => {
    const openDialogBtn = document.getElementById('openDialogBtn');
    const responsiveDialog = document.getElementById('responsiveDialog');
    const closeButtons = document.querySelectorAll('.close-btn, .cancel-btn'); // Select all close-related buttons

    // Function to open the dialog
    openDialogBtn.addEventListener('click', () => {
        responsiveDialog.classList.add('show');
    });

    // Function to close the dialog
    const closeDialog = () => {
        responsiveDialog.classList.remove('show');
    };

    // Add event listeners to close buttons
    closeButtons.forEach(button => {
        button.addEventListener('click', closeDialog);
    });

    // Close dialog when clicking outside of it (on the backdrop)
    responsiveDialog.addEventListener('click', (event) => {
        if (event.target === responsiveDialog) {
            closeDialog();
        }
    });

    // Close dialog when pressing the Escape key
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && responsiveDialog.classList.contains('show')) {
            closeDialog();
        }
    });
});